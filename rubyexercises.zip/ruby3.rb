codes = [65,66,67,68,69,70]
codes.map!(&:chr)
puts codes

