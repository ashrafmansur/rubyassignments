def temp_changer(nums)
	farenheit = ((nums*9)/5) + 32
	puts farenheit
end

temp_changer(0) #32
temp_changer(-15) #5
temp_changer(30) #86
temp_changer(100) #212